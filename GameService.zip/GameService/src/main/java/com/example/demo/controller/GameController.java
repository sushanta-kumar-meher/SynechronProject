package com.example.demo.controller;

import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Game;
import com.example.demo.service.GameService;
@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/api/v1/games")
public class GameController {
	
	@Autowired
	private GameService gameService;
	
	@PostMapping
	public Game createGame(@RequestBody Game game ) {
		
		return this.gameService.save(game);
	}
	
	@GetMapping
	public Set<Game> fetchAllGames(){
		return this.gameService.fetchGames();
	}
	
	@GetMapping("/{id}")
	public Game fetchGamerById(@PathVariable("id")long id) {
		return this.gameService.fetchGameById(id);
	}
	
	
	
	@DeleteMapping("/{id}")
	public void deleteGameById(@PathVariable("id")long id) {
		 this.gameService.deleteGameById(id);
	}

}
