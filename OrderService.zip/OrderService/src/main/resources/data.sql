insert into orders values(101,'sushanta',2200);
insert into orders values(102,'Ahil',1500);
insert into orders values(103,'kiran',2000);