package com.example.demo.service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.exception.InvalidProductException;
import com.example.demo.model.Product;
import com.example.demo.repository.ProductRepository;

@Service
public class ProductService {
	
	@Autowired
	private ProductRepository productRepository;
	
	public Product save(Product product) {
		return this.productRepository.save(product);
	}
	public Set<Product> fetchProduct(){
		return new HashSet<>(this.productRepository.findAll());
	}
	
public Product fetchProductById(long productId) {
		
		/*
		 * Optional<Order> optionalOrder = this.orderRepository.findById(orderId);
		 * 
		 * if (optionalOrder.isEmpty()) { throw new
		 * IllegalArgumentException("Invalid Order Id"); } return optionalOrder.get();
		 */
		
		return this.productRepository.findById(productId)
				.orElseThrow(() -> new InvalidProductException("Invalid order id"));
	}
	public void deleteProductrById(long productId) {
		this.productRepository.deleteById(productId);
	}

}
