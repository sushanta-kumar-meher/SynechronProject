package com.example.demo.controller;

import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Product;
import com.example.demo.service.ProductService;
@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/api/v1/products")

public class ProductController {
	
	@Autowired
	private ProductService productService;
	
	@PostMapping
	public Product createProduct(@RequestBody Product product ) {
		
		return this.productService.save(product);
	}
	@GetMapping
	public Set<Product> fetchAllProduct(){
		return this.productService.fetchProduct();
	}
	
	@GetMapping("/{id}")
	public Product getProductById(@PathVariable("id")long productId) {
		return this.productService.fetchProductById(productId);
	}
	
	
	
	@DeleteMapping("/{id}")
	public void deleteProductById(@PathVariable("id")long productId) {
		 this.productService.deleteProductrById(productId);
	}

}
