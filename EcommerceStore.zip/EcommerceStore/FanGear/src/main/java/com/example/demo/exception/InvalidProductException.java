package com.example.demo.exception;

public class InvalidProductException extends RuntimeException {
	
	public InvalidProductException(String message) {
		super(message);
	}
	
	@Override
	public String getMessage() {
		return super.getMessage();
	}

}
