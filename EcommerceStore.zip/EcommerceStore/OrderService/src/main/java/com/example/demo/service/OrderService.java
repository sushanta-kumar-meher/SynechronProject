package com.example.demo.service;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.exception.InvalidOrderException;
import com.example.demo.model.Order;
import com.example.demo.repository.OrderRepository;

import lombok.AllArgsConstructor;

@Service

public class OrderService {
	
	@Autowired
	private OrderRepository orderRepository;
	
	public Order save(Order order) {
		return this.orderRepository.save(order);
	}
	
	public Set<Order> fetchOrders(){
		return new HashSet<>(this.orderRepository.findAll());
	}
	
	public Order fetchOrderById(long orderId) {
		
		/*
		 * Optional<Order> optionalOrder = this.orderRepository.findById(orderId);
		 * 
		 * if (optionalOrder.isEmpty()) { throw new
		 * IllegalArgumentException("Invalid Order Id"); } return optionalOrder.get();
		 */
		
		return this.orderRepository.findById(orderId)
				.orElseThrow(() -> new InvalidOrderException("Invalid order id"));
	}
	
	public void deleteOrderById(long orderId) {
		this.orderRepository.deleteById(orderId);
	}
	
	
}
