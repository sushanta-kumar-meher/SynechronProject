insert into game values(101,'Cricket',1200);
insert into game values(102,'PubG',1500);
insert into game values(103,'Football',2000);