package com.example.demo.service;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.exception.InvalidGameException;
import com.example.demo.model.Game;
import com.example.demo.repository.GameRepository;

@Service
public class GameService {
	
	@Autowired
	private GameRepository gameRepository;
	
	public Game save(Game game) {
		return this.gameRepository.save(game);
	}
	
	public Set<Game> fetchGames(){
		return new HashSet<>(this.gameRepository.findAll());
	}
	
	public Game fetchGameById(long id) {
		
		/*
		 * Optional<Game> optionalGame = this.gameRepository.findById(id);
		 * 
		 * if (optionalGame.isEmpty()) { throw new
		 * IllegalArgumentException("Invalid Game Id"); } return optionalGame.get();
		 */
		
		return this.gameRepository.findById(id)
				.orElseThrow(() -> new InvalidGameException("Invalid game id"));
	}
	
	public void deleteGameById(long id) {
		this.gameRepository.deleteById(id);
	}
	
	

}
