package com.example.demo.exception;

public class InvalidGameException extends RuntimeException {
	
	public InvalidGameException(String message) {
		super(message);
	}
	
	@Override
	public String getMessage() {
		return super.getMessage();
	}

}
