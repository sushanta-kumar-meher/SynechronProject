package snippet;

public class Snippet {
	eureka:
	  instance:
	    prefer-ip-address: true
	  client:
	    fetch-registry: true
	    register-with-eureka: true
	    service-url:
	      default-zone: http://localhost:8761/eureka/
	
	server:
	  port: 5555
	
	
	spring:
	  cloud:
	    gateway:
	      routes:
	        - id: ordersserviceapplication
	          uri: lb://orderservice
	          predicates:
	            - Path=/orders/**
	          filters:
	            - RewritePath=/orders/(?<path>.*),/$\{path}
	        - id: inventoryserviceapplication
	          uri: lb://INVENTORYSERVICE
	          predicates:
	            - Path=/inventory/**
	          filters:
	            - RewritePath=/inventory/(?<path>.*), /$\{path}
	management:
	  endpoint:
	    gateway:
	      enabled: true  
	  endpoints:
	    web:
	      exposure:
	        include: "*"
	      
}

